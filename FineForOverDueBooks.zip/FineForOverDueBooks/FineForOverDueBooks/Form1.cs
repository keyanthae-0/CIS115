﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FineForOverDueBooks
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double NumOfBooks;
            double DaysOverDue;
            if (double.TryParse(textBox1.Text, out NumOfBooks) && double.TryParse(textBox2.Text, out DaysOverDue))
            {
                calculateFine(NumOfBooks, DaysOverDue);
            }
            else 
            {
                MessageBox.Show("PLEASE ENTER VALID NUMBERS!");            
            }

        }
        private void calculateFine(double books, double days) 
        {
            double fineCharge;
            if (days < 0) 
            {
                MessageBox.Show("You cannot have below zero days.");
                textBox2.Text = "";
            }
            else if (days > 0 && days <= 7) 
            {
                fineCharge = (books * days) * 0.10;
                label3.Text = $"You have {books} books overdue. They are late by {days} days you owe a fine of ${fineCharge}";
            }
            else
            {
                fineCharge = (((days - 7) * books) * 0.20) + ((books * 7) * 0.10);
                label3.Text = $"You have {books} books overdue. They are late by {days} days, you owe a fine of ${fineCharge}";
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
