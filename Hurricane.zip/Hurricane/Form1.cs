﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hurricane
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int CANE5 = 156, CANE4 = 130, CANE3 = 111, CANE2 = 96, CANE1 = 74;
            int windSpeed;
            windSpeed = Convert.ToInt32(textBox1.Text);
            if (windSpeed >= CANE5)
            {
                label2.Text = "Category 5 Hurricane.";
            }
            else if (windSpeed >= CANE4)
            {
                label2.Text = "Category 4 Hurricane.";
            }
            else if (windSpeed >= CANE3)
            {
                label2.Text = "Category 3 Hurricane.";
            }
            else if (windSpeed >= CANE2)
            {
                label2.Text = "Category 2 Hurricane";
            }
            else if (windSpeed >= CANE1)
            {
                label2.Text = "Category 1 Hurricane";
            }
            else 
            {
              if (windSpeed < CANE1)
                {
                    label2.Text = "This is not a hurricane.";
                }
            }
        }
    }
}
