﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PigLatin
{
    public partial class PigLatin : Form
    {
        public PigLatin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String word;
            String pigLatin;

            word = textBox1.Text;
            pigLatin = word.Substring(1, word.Length - 1) + word.Substring(0,1) + "ay";

            outPutext.Text = pigLatin;
        }
    }
}
