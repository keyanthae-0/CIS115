﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoveEstimator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double hours;
            double miles;
            hours = Convert.ToDouble(textBox1.Text);
            miles = Convert.ToDouble(textBox2.Text);
            double total = 200 + (150 * hours) + (2 * miles);
            label3.Text =$"For a move taking {hours} hours and going {miles} miles the estiamate is {total:C2}";         
        }
    }
}
