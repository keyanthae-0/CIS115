﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestScoreList
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int submissions = 0;
        public int[] testScoreList = { 0, 0, 0, 0, 0, 0, 0, 0 };
        public void button1_Click(object sender, EventArgs e)
        {
            int enteredScore;
            int enteredTest;
            const int maxTestScore = 100;
            const int minTestScore = 0;
            const int lowMax = 1;
            const int highMax = 8;
            if (int.TryParse(textBox1.Text, out enteredScore) && int.TryParse(textBox2.Text, out enteredTest))
            {
                if(int.Parse(textBox2.Text) > maxTestScore || (int.Parse(textBox2.Text) < minTestScore))
                {
                    MessageBox.Show("PLEASE ENTER A VALID TEST SCORE");
                }
                else
                {
                    if ((int.Parse(textBox1.Text) < lowMax || (int.Parse(textBox1.Text) > highMax)))
                    {
                        MessageBox.Show("Error! PLease enter tests ranging from 1-8.");
                        textBox1.Text = "";
                        textBox2.Text = "";
                    }
                    else
                    {
                        submissions++;
                        --enteredScore;
                        testScoreList[enteredScore] += enteredTest;
                        textBox1.Text = "";
                        textBox2.Text = "";
                        label4.Text = $"{submissions} test entered so far";
                        label3.Text = $"Test {enteredScore} Was entered and the score of {enteredTest} Was entered. Please enter another test and score";

                        if (submissions == 8)
                        {
                            button1.Enabled = false;
                        }
                    }
                }

            };
        }

        public void button2_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            textBox2.Enabled = false;
            textBox1.Enabled = false;
            int totalScores = 0;
            int avg;
            foreach (int scores in testScoreList)
            {
                totalScores += scores;
            }

            avg = totalScores / testScoreList.Length;

            for (int i = 0; i < testScoreList.Length; i++)
            {
                int scoreCounter = i + 1; 
                int distanceFrom = testScoreList[i] - avg;
                label5.Text += String.Format("The {0} score is {1}, this score is {2} from the average {3}\n", scoreCounter, testScoreList[i].ToString("G"), distanceFrom, avg);
            }
        }
    }
}
