﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRecommender_Project
{
    public partial class movies : Form
    {
        public movies()
        {
            InitializeComponent();
        }
        //Comedy, Horror, Drama, Romance, Thriller !! THIS IS THE ORDER IN WHICH THE GENRES WILL BE CALCULATED
        String[] movieArray = {"Forrest Gump", "Mean girls", "The hangover", "Step Brothers", "Napoleon Dynamite", "Scary Movie Trilogy", "Ted Trilogy", "Deadpool Trilogy",
                               "The conjuring Trilogy", "Twister (2024)", "John Wick trilogy", "The covenant", "Without Remorse", "Heart Eyes", "Jurassic World Trilogy", "Ready or not", "War Dogs",
                               "Carry on", "Hereditary", "Greater", "The Greatest Showman", "Wrath of men", "Wonder", "Terrifier Trilogy", "Hidden Figures", "End of Watch", "Good will hunting",
                               "The wolf of wall street", "The accountant Trilogy", "Oppenheimer", "Ferrari V Ford", "Gran Turismo", "Trap", "Ace Ventura: Pet Detective", "50 First dates"};
        int[,] movieGenreScores =
        {
            {40, 0, 50, 30, 20},  // Forrest Gump (drama, some comedy, minimal thriller)
            {50, 0, 20, 50, 10},  // Mean Girls (comedy, romance)
            {50, 5, 10, 10, 40},  // The Hangover (comedy, thriller)
            {60, 0, 30, 10, 5},  //Step Brothers (comedy, drama)
            {30, 5, 25, 5, 15},  // Napoleon Dynamite (comedy, light drama)
            {35, 50, 10, 0, 40},  // Scary Movie Trilogy (comedy, horror, thriller)
            {50, 10, 15, 10, 20},  // Ted Trilogy (comedy, light romance)
            {50, 30, 5, 10, 50},  // Deadpool Trilogy (action, comedy, thriller)
            {10, 60, 50, 5, 55},  // The Conjuring Trilogy (horror, thriller, drama)
            {15, 5, 35, 5, 40},  // Twister (2024) (drama, thriller, some horror)
            {20, 20, 20, 10, 50},  // John Wick Trilogy (action, thriller)
            {5, 10, 50, 5, 60},  // The Covenant (action, thriller, drama)
            {5, 5, 55, 10, 55},  // Without Remorse (thriller, drama)
            {30, 0, 25, 55, 20},  // Heart Eyes (drama, romance, thriller)
            {20, 10, 40, 30, 30},  // Jurassic World Trilogy (action, drama, light thriller)
            {20, 15, 20, 5, 40},  // Ready or Not (light horror, thriller)
            {40, 5, 15, 10, 45},  // War Dogs (comedy, action, thriller)
            {20, 15, 45, 10, 20},  // Carry on (comedy, drama)
            {40, 60, 20, 5, 50},  // Hereditary (horror, thriller, drama)
            {20, 5, 55, 5, 30},  // Greater (drama)
            {25, 10, 55, 20, 20},  // The Greatest Showman (drama, romance)
            {15, 10, 50, 20, 50},  // Wrath of Men (thriller, action, drama)
            {30, 0, 60, 10, 20},  // Wonder (drama)
            {10, 50, 40, 5, 60},  // Terrifier Trilogy (horror, thriller)
            {30, 10, 55, 10, 35},  // Hidden Figures (drama, historical)
            {40, 10, 50, 5, 55},  // End of Watch (thriller, action, drama)
            {45, 5, 60, 0, 40},  // Good Will Hunting (drama)
            {50, 0, 60, 10, 10},  // The Wolf of Wall Street (drama, some comedy)
            {5, 10, 55, 15, 50},  // The Accountant Trilogy (action, drama, thriller)
            {10, 0, 60, 10, 45},  // Oppenheimer (drama)
            {35, 0, 50, 5, 40},  // Ferrari V Ford (drama, some action)
            {40, 0, 45, 5, 20},  // Gran Turismo (action, drama)
            {25, 0, 50, 20, 40},  // Trap (action, thriller)
            {60, 0, 25, 5, 30},  // Ace Ventura: Pet Detective (comedy)
            {50, 0, 45, 35, 30},  // 50 First Dates (comedy, romance)
        };
        
        int movieScore = 0;
        int PreviousScore = 0;
        int comedyScore = 0;
        int horrorScore = 0;
        int dramaScore = 0;
        int romanceScore = 0;
        int thrillerScore = 0;
        
        private void button1_Click(object sender, EventArgs e) //Button to make the first question appear
        {
            PreviousScore = movieScore;
            question1.Visible = true; 

            drama_score.Visible = true;
            romance_score.Visible = true;
            thriller_score.Visible = true;
            horror_score.Visible = true;
            comedy_score.Visible = true;
        }

        private void exitBTN_Click(object sender, EventArgs e) // This will exit the quiz and reset everything back to the original state
        {
            movieScore = 0;
            PreviousScore = 0;

            comedyScore = 0;
            horrorScore = 0;
            dramaScore = 0;
            romanceScore = 0;
            thrillerScore = 0;

            Option1.Enabled = true;
            Option2.Enabled = true;
            Q2answer.Enabled = true;
            Q2answer2.Enabled = true;
            scareBTN1.Enabled = true;
            scareBTN2.Enabled = true;
            ActionAnswerN.Enabled = true;
            ActionAnswerY.Enabled = true;
            MaleAnswerY.Enabled = true;
            FemaleAnswerN.Enabled = true;
            Question6A.Enabled = true;
            Question6B.Enabled = true;
            Question7A.Enabled = true;
            Question7B.Enabled = true;
            question8A.Enabled = true;
            question8B.Enabled = true;
            question9A.Enabled = true;
            question9B.Enabled = true;
            question10A.Enabled = true;
            question10B.Enabled = true;

            question1.Visible = false;
            question2.Visible = false;
            Question3.Visible = false;
            question4.Visible = false;
            question5.Visible = false;
            question6.Visible = false;
            question7.Visible = false;  
            question8.Visible = false;
            question9.Visible = false;
            question10.Visible = false;

            Results.Visible = false;
            movie1.Text = "";
            movie2.Text = "";
            movie3.Text = "";
            UpdateScoreDisplay();
        } 

        private String[] GetTop3Movies()//Function i will be using to calculate the top 3 movies
        {
            // User's genre scores
            int[] userScores = { comedyScore, horrorScore, dramaScore, romanceScore, thrillerScore };

            // This will hold the distance (similarity) score for each movie.
            int[] movieDistances = new int[movieArray.Length];

            // Calculate the "distance" for each movie.
            for (int i = 0; i < movieArray.Length; i++)
            {
                // Extract the movie's genre scores
                int movieComedy = movieGenreScores[i, 0];  // Comedy score for movie
                int movieHorror = movieGenreScores[i, 1];   // Horror score for movie
                int movieDrama = movieGenreScores[i, 2];    // Drama score for movie
                int movieRomance = movieGenreScores[i, 3];  // Romance score for movie
                int movieThriller = movieGenreScores[i, 4]; // Thriller score for movie

                // Calculate the distance between the user's preferences and this movie's scores
                movieDistances[i] = CalculateDistance(movieComedy, movieHorror, movieDrama, movieRomance, movieThriller);
            }

            // Now find the 3 movies with the smallest distances (best matches)
            int[] topIndexes = new int[3] { -1, -1, -1 };
            int[] topDistances = new int[3] { int.MaxValue, int.MaxValue, int.MaxValue };

            for (int i = 0; i < movieDistances.Length; i++)
            {
                int distance = movieDistances[i];

                // Check if the distance qualifies for top 3 closest matches
                for (int j = 0; j < 3; j++)
                {
                    if (distance < topDistances[j]) // if current distance is smaller (closer match)
                    {
                        // Shift the farther distances down
                        for (int k = 2; k > j; k--)
                        {
                            topDistances[k] = topDistances[k - 1];
                            topIndexes[k] = topIndexes[k - 1];
                        }

                        // Insert new closest match
                        topDistances[j] = distance;
                        topIndexes[j] = i;
                        break;
                    }
                }
            }

            // Prepare the result with the top 3 closest movies
            string[] topMovies = new string[3];
            for (int i = 0; i < 3; i++)
            {
                topMovies[i] = topIndexes[i] != -1 ? movieArray[topIndexes[i]] : "N/A";
            }

            return topMovies;
        }

        private int CalculateDistance(int movieComedy, int movieHorror, int movieDrama, int movieRomance, int movieThriller) //Will be using this method to calculate the distance from each value to recommend you your best 3 movies
        {
            return Math.Abs(movieComedy - comedyScore)
                 + Math.Abs(movieHorror - horrorScore)
                 + Math.Abs(movieDrama - dramaScore)
                 + Math.Abs(movieRomance - romanceScore)
                 + Math.Abs(movieThriller - thrillerScore);
        }
        //Genre update Methods
        private void UpdateHorrorScore(int optionValue) //Updates the horror score
        {
            horrorScore += optionValue;
            movieScore += optionValue;
            UpdateScoreDisplay();
        }

        private void UpdateComedyScore(int optionValue) //Updates the comedy score
        {
            comedyScore += optionValue;
            movieScore += optionValue;
            UpdateScoreDisplay();
        }

        private void UpdateThrillerScore(int optionValue) //Updates the thriller score
        {
            thrillerScore += optionValue;
            movieScore += optionValue;
            UpdateScoreDisplay();
        }
        private void UpdateRomanceScore(int optionValue) //Updates the romance score
        {
            romanceScore += optionValue;
            movieScore += optionValue;
            UpdateScoreDisplay();
        }
        private void UpdateDramaScore(int optionValue) //Updates the drama score
        {
            dramaScore += optionValue;
            movieScore += optionValue;
            UpdateScoreDisplay();
        }

        //update total score method
        private void UpdateScoreDisplay()
        {
            horror_score.Text = $"Horror Genre Score: {horrorScore}"; //Updates the horror text
            comedy_score.Text = $"Comedy Genre Score: {comedyScore}"; //Updates the comedy text
            romance_score.Text = $"Romance Genre Score: {romanceScore}"; //Updates the romance text
            drama_score.Text = $"Drama Genre Score: {dramaScore}"; //updates the drama text
            thriller_score.Text = $"Thriller Genre Score: {thrillerScore}"; //Updates the thriller text
        }

        //continue button calculations
        private void continueBTN_Click(object sender, EventArgs e)
        {
            question1.Visible = false;
            PreviousScore = movieScore;
            question2.Visible = true; // This will continue onto the next question
        }

        private void continueBTN2_Click(object sender, EventArgs e)
        {
            question2.Visible = false; //This hides the current question
            Question3.Visible = true; //This makes the next question appear
            PreviousScore = movieScore;
        }
        private void ContinueBTN3_Click(object sender, EventArgs e)
        {
            Question3.Visible = false;//This hides the current question
            question4.Visible = true; //This makes the next question appear
            PreviousScore = movieScore;
        }

        private void continueBTN4_Click(object sender, EventArgs e)
        {
            PreviousScore = movieScore;
            question4.Visible = false;//This hides the current question
            question5.Visible = true; //This makes the next question appear
        }
        private void continueBTN5_Click(object sender, EventArgs e)
        {
            PreviousScore = movieScore;
            question5.Visible = false;//This hides the current question
            question6.Visible = true; //This makes the next question appear
        }
        private void continueBTN6_Click(object sender, EventArgs e)
        {
            PreviousScore = movieScore;
            question6.Visible = false;//This hides the current question
            question7.Visible = true; //This makes the next question appear
        }
        private void ContinueBTN7_Click(object sender, EventArgs e)
        {
            PreviousScore = movieScore;
            question7.Visible = false;//This hides the current question
            question8.Visible = true; //This makes the next question appear
        }
        private void continueBTN8_Click(object sender, EventArgs e)
        {
            PreviousScore = movieScore;
            question8.Visible = false;//This hides the current question
            question9.Visible = true; //This makes the next question appear
        }
        private void continueBTN9_Click(object sender, EventArgs e)
        {
            PreviousScore = movieScore;
            question9.Visible = false;//This hides the current question
            question10.Visible = true; //This makes the next question appear
        }
        private void continueBTN10_Click(object sender, EventArgs e)
        {
            PreviousScore = movieScore;
            question10.Visible = false; //This makes the next question appear
            Results.Visible = true;//This will display your 3 most recommended movies

            string[] TopMovies = GetTop3Movies(); //This will display your top 3 recommendations
            movie1.Text = TopMovies[0];
            movie2.Text = TopMovies[1];
            movie3.Text = TopMovies[2];
        }
       
        //Would you rather see awkward funny moments or emotional charcater growth? -- QUESTION 2
        private void YesBTN_Click(object sender, EventArgs e) //Funny moments
        {
            const int optionValue = 15; 
            UpdateComedyScore(optionValue);
            UpdateDramaScore(5);
            UpdateRomanceScore(3);
            continueBTN.Visible = true;
            Option1.Enabled = false;
            Option2.Enabled = false;
        }

        private void NoBTN_Click(object sender, EventArgs e) //Character Growth -- QUESTION 2
        {
            const int optionValue = 6; 
            UpdateDramaScore(optionValue);
            UpdateRomanceScore(optionValue);
            Option2.Enabled = false;
            Option1.Enabled = false;
            continueBTN.Visible = true;
        }

        //Would you prefer movies that make you laugh? or hide behind a pillow/blanket? -- QUESTION 2

        private void Q2answer_Click(object sender, EventArgs e) //Laugh
        {
            const int optionValue = 12;
            UpdateDramaScore(5);
            UpdateRomanceScore(3);
            UpdateComedyScore(optionValue);
            Q2answer.Enabled = false;
            Q2answer2.Enabled = false;
            continueBTN2.Visible = true;
        }

        private void Q2answer2_Click(object sender, EventArgs e) //Hide
        {
            const int optionValue = 15;
            UpdateHorrorScore(optionValue);
            Q2answer2.Enabled = false;
            Q2answer.Enabled = false;
            continueBTN2.Visible = true;
        }

       //Do you like movies that put you on the edge of your seat? or to be more relaxed? -- QUESTION 3
        private void scareBTN1_Click(object sender, EventArgs e) //Edge of my seat 
        {
            const int optionValue = 12;
            UpdateThrillerScore(optionValue);
            scareBTN1.Enabled = false;
            scareBTN2.Enabled = false;
            ContinueBTN3.Visible = true;
        }

        private void scareBTN2_Click(object sender, EventArgs e)// Relaxed
        {
            const int optionValue = 7;
            UpdateComedyScore(5);
            UpdateDramaScore(optionValue);
            UpdateRomanceScore(optionValue);
            ContinueBTN3.Visible = true;
            scareBTN2.Enabled = false;
            scareBTN1.Enabled = false;
        }

        //Would you rather watch a movie about falling in love or about survival -- QUESTION 4
        private void ActionAnswerY_Click(object sender, EventArgs e) //Falling in love
        {
            const int optionValue = 15;
            UpdateRomanceScore(optionValue);
            continueBTN4.Visible = true;
            ActionAnswerN.Enabled = false;
            ActionAnswerY.Enabled = false;
            
        }

        private void ActionAnswerN_Click(object sender, EventArgs e) // Survival
        {
            const int optionValue = 10;
            UpdateThrillerScore(optionValue);
            UpdateHorrorScore(3);
            continueBTN4.Visible = true;
            ActionAnswerN.Enabled = false;
            ActionAnswerY.Enabled = false;
        }

        //Would you rather watch a film thats dark and mysterious or uplifting and sweet? -- QUESTION 5
        private void MaleAnswerY_Click(object sender, EventArgs e) // Dark/Mysterious
        {
            const int optionValue = 5;
            UpdateHorrorScore(optionValue);
            UpdateThrillerScore(optionValue);
            continueBTN5.Visible = true;
            MaleAnswerY.Enabled = false;
            FemaleAnswerN.Enabled = false;
            
        }

        private void FemaleAnswerN_Click(object sender, EventArgs e) // Uplifting/Sweet
        {
            const int optionValue = 10;
            UpdateRomanceScore(optionValue);
            UpdateDramaScore(2);
            continueBTN5.Visible = true;
            MaleAnswerY.Enabled = false;
            FemaleAnswerN.Enabled = false;
        }
        //Would you rather choose awkward first dates or haunted basements? -- QUESTION 6
        private void Question6A_Click(object sender, EventArgs e) //Awkward first dates
        {
            const int optionValue = 8;
            UpdateComedyScore(optionValue);
            UpdateDramaScore(4);
            UpdateRomanceScore(optionValue);
            continueBTN6.Visible = true;
            Question6A.Enabled = false;
            Question6B.Enabled = false;
            
        }
        private void Question6B_Click(object sender, EventArgs e) //Haunted Basements
        {
            const int optionValue = 13;
            UpdateHorrorScore(optionValue);
            continueBTN6.Visible = true;
            Question6A.Enabled = false;
            Question6B.Enabled = false;
            
        }
        //Do you enjoy seeing movies with real life struggles or seeing someone outsmart the villian? -- QUESTION 7
        private void Question7A_Click(object sender, EventArgs e) // Real life struggles
        {
            const int optionValue = 10;
            UpdateDramaScore(optionValue);
            UpdateRomanceScore(4);
            ContinueBTN7.Visible = true;
            Question7A.Enabled = false;
            Question7B.Enabled = false;
            
        }

        private void Question7B_Click(object sender, EventArgs e) //Outsmart the villian 
        {
            const int optionValue = 8;
            UpdateHorrorScore(optionValue);
            UpdateThrillerScore(optionValue);
            ContinueBTN7.Visible = true;
            Question7A.Enabled = false;
            Question7B.Enabled = false;
            
        }

        //Do you enjoy family conflicts or supernatural thrills? -- QUESTION 8
        private void question8A_Click(object sender, EventArgs e) //Family conflicts 
        {
            const int optionValue = 10;
            UpdateDramaScore(optionValue);
            UpdateRomanceScore(2);
            continueBTN8.Visible = true;
            question8A.Enabled = false;
            question8B.Enabled = false;
            
        }

        private void question8B_Click(object sender, EventArgs e) //Supernatural thrills
        {
            const int optionValue = 9;
            UpdateHorrorScore(optionValue);
            UpdateThrillerScore(4);
            continueBTN8.Visible = true;
            question8A.Enabled = false;
            question8B.Enabled = false;
            
        }

        //Would you rather watch a movie with a threat that builds slowly overtime or where the danger is intense and immediate -- QUESTION 9
        private void question9A_Click(object sender, EventArgs e) //Builds slowly
        {
            const int optionValue = 15;
            UpdateThrillerScore(optionValue);
            continueBTN9.Visible = true;
            question9A.Enabled = false;
            question9B.Enabled = false;
            
        }

        private void question9B_Click(object sender, EventArgs e) // Intense and immediate
        {
            const int optionValue = 10;
            UpdateHorrorScore(optionValue);
            continueBTN9.Visible = true;
            question9A.Enabled = false;
            question9B.Enabled = false;
        }

        //Do you enjoy a lot of fighting moments or moments with self reflection? -- QUESTION 10

        private void question10A_Click(object sender, EventArgs e) //Fighting
        {
            const int optionValue = 5;
            UpdateThrillerScore(optionValue);
            continueBTN10.Visible = true;
            question10A.Enabled = false;
            question10B.Enabled = false;
            
        }

        private void question10B_Click(object sender, EventArgs e) //Self reflection
        {
            const int optionValue = 7;
            UpdateDramaScore(optionValue);
            UpdateRomanceScore(3);
            UpdateComedyScore(optionValue);
            continueBTN10.Visible = true;
            question10A.Enabled = false;
            question10B.Enabled = false;
            
        }
    }
}
