﻿namespace MovieRecommender_Project
{
    partial class movies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.question1 = new System.Windows.Forms.GroupBox();
            this.continueBTN = new System.Windows.Forms.Button();
            this.pointTotal = new System.Windows.Forms.Label();
            this.Option2 = new System.Windows.Forms.Button();
            this.Option1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.question2 = new System.Windows.Forms.GroupBox();
            this.continueBTN2 = new System.Windows.Forms.Button();
            this.PointTotal2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Q2answer2 = new System.Windows.Forms.Button();
            this.Q2answer = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.container = new System.Windows.Forms.Panel();
            this.comedy_score = new System.Windows.Forms.Label();
            this.Question3 = new System.Windows.Forms.GroupBox();
            this.ContinueBTN3 = new System.Windows.Forms.Button();
            this.pointTotal3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.scareBTN2 = new System.Windows.Forms.Button();
            this.scareBTN1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.question5 = new System.Windows.Forms.GroupBox();
            this.continueBTN5 = new System.Windows.Forms.Button();
            this.pointTotal5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.FemaleAnswerN = new System.Windows.Forms.Button();
            this.MaleAnswerY = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.drama_score = new System.Windows.Forms.Label();
            this.question4 = new System.Windows.Forms.GroupBox();
            this.continueBTN4 = new System.Windows.Forms.Button();
            this.pointTotal4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.ActionAnswerN = new System.Windows.Forms.Button();
            this.ActionAnswerY = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.thriller_score = new System.Windows.Forms.Label();
            this.question6 = new System.Windows.Forms.GroupBox();
            this.continueBTN6 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.Question6B = new System.Windows.Forms.Button();
            this.Question6A = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.question10 = new System.Windows.Forms.GroupBox();
            this.continueBTN10 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.question10B = new System.Windows.Forms.Button();
            this.question10A = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.romance_score = new System.Windows.Forms.Label();
            this.horror_score = new System.Windows.Forms.Label();
            this.question9 = new System.Windows.Forms.GroupBox();
            this.continueBTN9 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.question9B = new System.Windows.Forms.Button();
            this.question9A = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.question8 = new System.Windows.Forms.GroupBox();
            this.continueBTN8 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.question8B = new System.Windows.Forms.Button();
            this.question8A = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.question7 = new System.Windows.Forms.GroupBox();
            this.ContinueBTN7 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.Question7B = new System.Windows.Forms.Button();
            this.Question7A = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.exitBTN = new System.Windows.Forms.Button();
            this.Results = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.movie3 = new System.Windows.Forms.Button();
            this.movie2 = new System.Windows.Forms.Button();
            this.movie1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.question1.SuspendLayout();
            this.question2.SuspendLayout();
            this.container.SuspendLayout();
            this.Question3.SuspendLayout();
            this.question5.SuspendLayout();
            this.question4.SuspendLayout();
            this.question6.SuspendLayout();
            this.question10.SuspendLayout();
            this.question9.SuspendLayout();
            this.question8.SuspendLayout();
            this.question7.SuspendLayout();
            this.Results.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(102, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(757, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Don\'t know what movies to watch? Well you\'ve come to the right place!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label2.Location = new System.Drawing.Point(73, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(746, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "You will be asked 10 questions about your movie preferences and at the end you wi" +
    "ll know what to watch!";
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(125, 86);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 39);
            this.button1.TabIndex = 2;
            this.button1.Text = "Begin";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.UseWaitCursor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // question1
            // 
            this.question1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.question1.Controls.Add(this.continueBTN);
            this.question1.Controls.Add(this.pointTotal);
            this.question1.Controls.Add(this.Option2);
            this.question1.Controls.Add(this.Option1);
            this.question1.Controls.Add(this.label3);
            this.question1.Location = new System.Drawing.Point(125, 131);
            this.question1.Name = "question1";
            this.question1.Size = new System.Drawing.Size(606, 301);
            this.question1.TabIndex = 3;
            this.question1.TabStop = false;
            this.question1.Visible = false;
            // 
            // continueBTN
            // 
            this.continueBTN.BackColor = System.Drawing.SystemColors.WindowText;
            this.continueBTN.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.continueBTN.Location = new System.Drawing.Point(257, 255);
            this.continueBTN.Name = "continueBTN";
            this.continueBTN.Size = new System.Drawing.Size(75, 23);
            this.continueBTN.TabIndex = 8;
            this.continueBTN.Text = "Continue...";
            this.continueBTN.UseVisualStyleBackColor = false;
            this.continueBTN.Visible = false;
            this.continueBTN.Click += new System.EventHandler(this.continueBTN_Click);
            // 
            // pointTotal
            // 
            this.pointTotal.AutoSize = true;
            this.pointTotal.Location = new System.Drawing.Point(254, 54);
            this.pointTotal.Name = "pointTotal";
            this.pointTotal.Size = new System.Drawing.Size(0, 13);
            this.pointTotal.TabIndex = 4;
            // 
            // Option2
            // 
            this.Option2.BackColor = System.Drawing.SystemColors.MenuText;
            this.Option2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Option2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Option2.Location = new System.Drawing.Point(313, 119);
            this.Option2.Name = "Option2";
            this.Option2.Size = new System.Drawing.Size(227, 103);
            this.Option2.TabIndex = 2;
            this.Option2.Text = "Emotional Character growth\r\n";
            this.Option2.UseVisualStyleBackColor = false;
            this.Option2.Click += new System.EventHandler(this.NoBTN_Click);
            // 
            // Option1
            // 
            this.Option1.BackColor = System.Drawing.SystemColors.MenuText;
            this.Option1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Option1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Option1.Location = new System.Drawing.Point(46, 119);
            this.Option1.Name = "Option1";
            this.Option1.Size = new System.Drawing.Size(227, 103);
            this.Option1.TabIndex = 1;
            this.Option1.Text = "Funny moments";
            this.Option1.UseVisualStyleBackColor = false;
            this.Option1.Click += new System.EventHandler(this.YesBTN_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Info;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(611, 54);
            this.label3.TabIndex = 0;
            this.label3.Text = "Would you rather see awkward funny moments or emotional character\r\n growth?\r\n";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // question2
            // 
            this.question2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.question2.Controls.Add(this.continueBTN2);
            this.question2.Controls.Add(this.PointTotal2);
            this.question2.Controls.Add(this.label6);
            this.question2.Controls.Add(this.Q2answer2);
            this.question2.Controls.Add(this.Q2answer);
            this.question2.Controls.Add(this.label8);
            this.question2.Location = new System.Drawing.Point(125, 131);
            this.question2.Name = "question2";
            this.question2.Size = new System.Drawing.Size(606, 301);
            this.question2.TabIndex = 8;
            this.question2.TabStop = false;
            this.question2.Visible = false;
            // 
            // continueBTN2
            // 
            this.continueBTN2.BackColor = System.Drawing.SystemColors.MenuText;
            this.continueBTN2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.continueBTN2.Location = new System.Drawing.Point(255, 260);
            this.continueBTN2.Name = "continueBTN2";
            this.continueBTN2.Size = new System.Drawing.Size(75, 23);
            this.continueBTN2.TabIndex = 9;
            this.continueBTN2.Text = "Continue...";
            this.continueBTN2.UseVisualStyleBackColor = false;
            this.continueBTN2.Visible = false;
            this.continueBTN2.Click += new System.EventHandler(this.continueBTN2_Click);
            // 
            // PointTotal2
            // 
            this.PointTotal2.AutoSize = true;
            this.PointTotal2.Location = new System.Drawing.Point(271, 57);
            this.PointTotal2.Name = "PointTotal2";
            this.PointTotal2.Size = new System.Drawing.Size(0, 13);
            this.PointTotal2.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(271, 82);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 4;
            // 
            // Q2answer2
            // 
            this.Q2answer2.BackColor = System.Drawing.SystemColors.MenuText;
            this.Q2answer2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q2answer2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Q2answer2.Location = new System.Drawing.Point(313, 128);
            this.Q2answer2.Name = "Q2answer2";
            this.Q2answer2.Size = new System.Drawing.Size(227, 103);
            this.Q2answer2.TabIndex = 2;
            this.Q2answer2.Text = "Hide";
            this.Q2answer2.UseVisualStyleBackColor = false;
            this.Q2answer2.Click += new System.EventHandler(this.Q2answer2_Click);
            // 
            // Q2answer
            // 
            this.Q2answer.BackColor = System.Drawing.SystemColors.MenuText;
            this.Q2answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q2answer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Q2answer.Location = new System.Drawing.Point(46, 128);
            this.Q2answer.Name = "Q2answer";
            this.Q2answer.Size = new System.Drawing.Size(227, 103);
            this.Q2answer.TabIndex = 1;
            this.Q2answer.Text = "Laugh";
            this.Q2answer.UseVisualStyleBackColor = false;
            this.Q2answer.Click += new System.EventHandler(this.Q2answer_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.Info;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(606, 57);
            this.label8.TabIndex = 0;
            this.label8.Text = "Would you prefer movies that make you laugh? or hide behind a pillow/blanket?\r\n";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // container
            // 
            this.container.AutoScroll = true;
            this.container.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.container.Controls.Add(this.Results);
            this.container.Controls.Add(this.question10);
            this.container.Controls.Add(this.question9);
            this.container.Controls.Add(this.question8);
            this.container.Controls.Add(this.question7);
            this.container.Controls.Add(this.question6);
            this.container.Controls.Add(this.question5);
            this.container.Controls.Add(this.question4);
            this.container.Controls.Add(this.Question3);
            this.container.Controls.Add(this.question2);
            this.container.Controls.Add(this.comedy_score);
            this.container.Controls.Add(this.drama_score);
            this.container.Controls.Add(this.thriller_score);
            this.container.Controls.Add(this.romance_score);
            this.container.Controls.Add(this.horror_score);
            this.container.Controls.Add(this.label9);
            this.container.Controls.Add(this.exitBTN);
            this.container.Controls.Add(this.question1);
            this.container.Controls.Add(this.button1);
            this.container.Controls.Add(this.label2);
            this.container.Controls.Add(this.label1);
            this.container.Dock = System.Windows.Forms.DockStyle.Fill;
            this.container.Location = new System.Drawing.Point(0, 0);
            this.container.Name = "container";
            this.container.Size = new System.Drawing.Size(921, 553);
            this.container.TabIndex = 0;
            // 
            // comedy_score
            // 
            this.comedy_score.AutoSize = true;
            this.comedy_score.Location = new System.Drawing.Point(744, 308);
            this.comedy_score.Name = "comedy_score";
            this.comedy_score.Size = new System.Drawing.Size(0, 13);
            this.comedy_score.TabIndex = 19;
            this.comedy_score.Visible = false;
            // 
            // Question3
            // 
            this.Question3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Question3.Controls.Add(this.ContinueBTN3);
            this.Question3.Controls.Add(this.pointTotal3);
            this.Question3.Controls.Add(this.label10);
            this.Question3.Controls.Add(this.scareBTN2);
            this.Question3.Controls.Add(this.label12);
            this.Question3.Controls.Add(this.scareBTN1);
            this.Question3.Location = new System.Drawing.Point(125, 131);
            this.Question3.Name = "Question3";
            this.Question3.Size = new System.Drawing.Size(613, 304);
            this.Question3.TabIndex = 9;
            this.Question3.TabStop = false;
            this.Question3.Visible = false;
            // 
            // ContinueBTN3
            // 
            this.ContinueBTN3.BackColor = System.Drawing.SystemColors.MenuText;
            this.ContinueBTN3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ContinueBTN3.Location = new System.Drawing.Point(260, 269);
            this.ContinueBTN3.Margin = new System.Windows.Forms.Padding(2);
            this.ContinueBTN3.Name = "ContinueBTN3";
            this.ContinueBTN3.Size = new System.Drawing.Size(69, 22);
            this.ContinueBTN3.TabIndex = 12;
            this.ContinueBTN3.Text = "Continue...";
            this.ContinueBTN3.UseVisualStyleBackColor = false;
            this.ContinueBTN3.Visible = false;
            this.ContinueBTN3.Click += new System.EventHandler(this.ContinueBTN3_Click);
            // 
            // pointTotal3
            // 
            this.pointTotal3.AutoSize = true;
            this.pointTotal3.Location = new System.Drawing.Point(271, 44);
            this.pointTotal3.Name = "pointTotal3";
            this.pointTotal3.Size = new System.Drawing.Size(0, 13);
            this.pointTotal3.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(271, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 13);
            this.label10.TabIndex = 8;
            // 
            // scareBTN2
            // 
            this.scareBTN2.BackColor = System.Drawing.SystemColors.MenuText;
            this.scareBTN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scareBTN2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.scareBTN2.Location = new System.Drawing.Point(311, 151);
            this.scareBTN2.Name = "scareBTN2";
            this.scareBTN2.Size = new System.Drawing.Size(227, 103);
            this.scareBTN2.TabIndex = 2;
            this.scareBTN2.Text = "Relaxed";
            this.scareBTN2.UseVisualStyleBackColor = false;
            this.scareBTN2.Click += new System.EventHandler(this.scareBTN2_Click);
            // 
            // scareBTN1
            // 
            this.scareBTN1.BackColor = System.Drawing.SystemColors.MenuText;
            this.scareBTN1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scareBTN1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.scareBTN1.Location = new System.Drawing.Point(44, 151);
            this.scareBTN1.Name = "scareBTN1";
            this.scareBTN1.Size = new System.Drawing.Size(227, 103);
            this.scareBTN1.TabIndex = 1;
            this.scareBTN1.Text = "Edge of my seat\r\n";
            this.scareBTN1.UseVisualStyleBackColor = false;
            this.scareBTN1.Click += new System.EventHandler(this.scareBTN1_Click);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.Info;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(-4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(615, 69);
            this.label12.TabIndex = 0;
            this.label12.Text = "Do you like movies that put you on the edge of your seat? or to be more relaxed?\r" +
    "\n\r\n";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // question5
            // 
            this.question5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.question5.Controls.Add(this.continueBTN5);
            this.question5.Controls.Add(this.pointTotal5);
            this.question5.Controls.Add(this.label15);
            this.question5.Controls.Add(this.FemaleAnswerN);
            this.question5.Controls.Add(this.MaleAnswerY);
            this.question5.Controls.Add(this.label16);
            this.question5.Location = new System.Drawing.Point(125, 131);
            this.question5.Name = "question5";
            this.question5.Size = new System.Drawing.Size(613, 304);
            this.question5.TabIndex = 14;
            this.question5.TabStop = false;
            this.question5.Visible = false;
            // 
            // continueBTN5
            // 
            this.continueBTN5.BackColor = System.Drawing.SystemColors.MenuText;
            this.continueBTN5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.continueBTN5.Location = new System.Drawing.Point(256, 276);
            this.continueBTN5.Margin = new System.Windows.Forms.Padding(2);
            this.continueBTN5.Name = "continueBTN5";
            this.continueBTN5.Size = new System.Drawing.Size(69, 22);
            this.continueBTN5.TabIndex = 12;
            this.continueBTN5.Text = "Continue...";
            this.continueBTN5.UseVisualStyleBackColor = false;
            this.continueBTN5.Visible = false;
            this.continueBTN5.Click += new System.EventHandler(this.continueBTN5_Click);
            // 
            // pointTotal5
            // 
            this.pointTotal5.AutoSize = true;
            this.pointTotal5.Location = new System.Drawing.Point(271, 44);
            this.pointTotal5.Name = "pointTotal5";
            this.pointTotal5.Size = new System.Drawing.Size(0, 13);
            this.pointTotal5.TabIndex = 11;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(271, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 13);
            this.label15.TabIndex = 8;
            // 
            // FemaleAnswerN
            // 
            this.FemaleAnswerN.BackColor = System.Drawing.SystemColors.MenuText;
            this.FemaleAnswerN.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FemaleAnswerN.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.FemaleAnswerN.Location = new System.Drawing.Point(311, 151);
            this.FemaleAnswerN.Name = "FemaleAnswerN";
            this.FemaleAnswerN.Size = new System.Drawing.Size(227, 103);
            this.FemaleAnswerN.TabIndex = 2;
            this.FemaleAnswerN.Text = "Uplifting and sweet";
            this.FemaleAnswerN.UseVisualStyleBackColor = false;
            this.FemaleAnswerN.Click += new System.EventHandler(this.FemaleAnswerN_Click);
            // 
            // MaleAnswerY
            // 
            this.MaleAnswerY.BackColor = System.Drawing.SystemColors.MenuText;
            this.MaleAnswerY.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaleAnswerY.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.MaleAnswerY.Location = new System.Drawing.Point(44, 151);
            this.MaleAnswerY.Name = "MaleAnswerY";
            this.MaleAnswerY.Size = new System.Drawing.Size(227, 103);
            this.MaleAnswerY.TabIndex = 1;
            this.MaleAnswerY.Text = "Dark and\r\n Mysterious";
            this.MaleAnswerY.UseVisualStyleBackColor = false;
            this.MaleAnswerY.Click += new System.EventHandler(this.MaleAnswerY_Click);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.Info;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(613, 54);
            this.label16.TabIndex = 0;
            this.label16.Text = "Would you watch a film thats dark and mysterious or uplifting and sweet?";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // drama_score
            // 
            this.drama_score.AutoSize = true;
            this.drama_score.Location = new System.Drawing.Point(744, 295);
            this.drama_score.Name = "drama_score";
            this.drama_score.Size = new System.Drawing.Size(0, 13);
            this.drama_score.TabIndex = 18;
            this.drama_score.Visible = false;
            // 
            // question4
            // 
            this.question4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.question4.Controls.Add(this.continueBTN4);
            this.question4.Controls.Add(this.pointTotal4);
            this.question4.Controls.Add(this.label13);
            this.question4.Controls.Add(this.ActionAnswerN);
            this.question4.Controls.Add(this.ActionAnswerY);
            this.question4.Controls.Add(this.label14);
            this.question4.Location = new System.Drawing.Point(125, 131);
            this.question4.Name = "question4";
            this.question4.Size = new System.Drawing.Size(613, 304);
            this.question4.TabIndex = 13;
            this.question4.TabStop = false;
            this.question4.Visible = false;
            // 
            // continueBTN4
            // 
            this.continueBTN4.BackColor = System.Drawing.SystemColors.MenuText;
            this.continueBTN4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.continueBTN4.Location = new System.Drawing.Point(257, 268);
            this.continueBTN4.Margin = new System.Windows.Forms.Padding(2);
            this.continueBTN4.Name = "continueBTN4";
            this.continueBTN4.Size = new System.Drawing.Size(69, 22);
            this.continueBTN4.TabIndex = 12;
            this.continueBTN4.Text = "Continue...";
            this.continueBTN4.UseVisualStyleBackColor = false;
            this.continueBTN4.Visible = false;
            this.continueBTN4.Click += new System.EventHandler(this.continueBTN4_Click);
            // 
            // pointTotal4
            // 
            this.pointTotal4.AutoSize = true;
            this.pointTotal4.Location = new System.Drawing.Point(271, 44);
            this.pointTotal4.Name = "pointTotal4";
            this.pointTotal4.Size = new System.Drawing.Size(0, 13);
            this.pointTotal4.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(271, 57);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 13);
            this.label13.TabIndex = 8;
            // 
            // ActionAnswerN
            // 
            this.ActionAnswerN.BackColor = System.Drawing.SystemColors.MenuText;
            this.ActionAnswerN.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ActionAnswerN.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ActionAnswerN.Location = new System.Drawing.Point(311, 151);
            this.ActionAnswerN.Name = "ActionAnswerN";
            this.ActionAnswerN.Size = new System.Drawing.Size(227, 103);
            this.ActionAnswerN.TabIndex = 2;
            this.ActionAnswerN.Text = "Fighting";
            this.ActionAnswerN.UseVisualStyleBackColor = false;
            this.ActionAnswerN.Click += new System.EventHandler(this.ActionAnswerN_Click);
            // 
            // ActionAnswerY
            // 
            this.ActionAnswerY.BackColor = System.Drawing.SystemColors.MenuText;
            this.ActionAnswerY.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ActionAnswerY.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ActionAnswerY.Location = new System.Drawing.Point(44, 151);
            this.ActionAnswerY.Name = "ActionAnswerY";
            this.ActionAnswerY.Size = new System.Drawing.Size(227, 103);
            this.ActionAnswerY.TabIndex = 1;
            this.ActionAnswerY.Text = "Love";
            this.ActionAnswerY.UseVisualStyleBackColor = false;
            this.ActionAnswerY.Click += new System.EventHandler(this.ActionAnswerY_Click);
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.Info;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(613, 57);
            this.label14.TabIndex = 0;
            this.label14.Text = "Would you rather watch a movie about falling in love or about survival?\r\n";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // thriller_score
            // 
            this.thriller_score.AutoSize = true;
            this.thriller_score.Location = new System.Drawing.Point(744, 282);
            this.thriller_score.Name = "thriller_score";
            this.thriller_score.Size = new System.Drawing.Size(0, 13);
            this.thriller_score.TabIndex = 17;
            this.thriller_score.Visible = false;
            // 
            // question6
            // 
            this.question6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.question6.Controls.Add(this.continueBTN6);
            this.question6.Controls.Add(this.label18);
            this.question6.Controls.Add(this.Question6B);
            this.question6.Controls.Add(this.Question6A);
            this.question6.Controls.Add(this.label19);
            this.question6.Location = new System.Drawing.Point(125, 131);
            this.question6.Name = "question6";
            this.question6.Size = new System.Drawing.Size(613, 304);
            this.question6.TabIndex = 14;
            this.question6.TabStop = false;
            this.question6.Visible = false;
            // 
            // continueBTN6
            // 
            this.continueBTN6.BackColor = System.Drawing.SystemColors.MenuText;
            this.continueBTN6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.continueBTN6.Location = new System.Drawing.Point(255, 268);
            this.continueBTN6.Margin = new System.Windows.Forms.Padding(2);
            this.continueBTN6.Name = "continueBTN6";
            this.continueBTN6.Size = new System.Drawing.Size(69, 22);
            this.continueBTN6.TabIndex = 12;
            this.continueBTN6.Text = "Continue...";
            this.continueBTN6.UseVisualStyleBackColor = false;
            this.continueBTN6.Visible = false;
            this.continueBTN6.Click += new System.EventHandler(this.continueBTN6_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(271, 57);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 13);
            this.label18.TabIndex = 8;
            // 
            // Question6B
            // 
            this.Question6B.BackColor = System.Drawing.SystemColors.MenuText;
            this.Question6B.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Question6B.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Question6B.Location = new System.Drawing.Point(311, 151);
            this.Question6B.Name = "Question6B";
            this.Question6B.Size = new System.Drawing.Size(227, 103);
            this.Question6B.TabIndex = 2;
            this.Question6B.Text = "Haunted basements";
            this.Question6B.UseVisualStyleBackColor = false;
            this.Question6B.Click += new System.EventHandler(this.Question6B_Click);
            // 
            // Question6A
            // 
            this.Question6A.BackColor = System.Drawing.SystemColors.MenuText;
            this.Question6A.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Question6A.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Question6A.Location = new System.Drawing.Point(44, 151);
            this.Question6A.Name = "Question6A";
            this.Question6A.Size = new System.Drawing.Size(227, 103);
            this.Question6A.TabIndex = 1;
            this.Question6A.Text = "Awkward first dates";
            this.Question6A.UseVisualStyleBackColor = false;
            this.Question6A.Click += new System.EventHandler(this.Question6A_Click);
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.Info;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(0, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(613, 41);
            this.label19.TabIndex = 0;
            this.label19.Text = "Would you choose awkward first dates or haunted basements?\r\n";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // question10
            // 
            this.question10.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.question10.Controls.Add(this.continueBTN10);
            this.question10.Controls.Add(this.label30);
            this.question10.Controls.Add(this.question10B);
            this.question10.Controls.Add(this.question10A);
            this.question10.Controls.Add(this.label31);
            this.question10.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.question10.Location = new System.Drawing.Point(125, 131);
            this.question10.Name = "question10";
            this.question10.Size = new System.Drawing.Size(613, 304);
            this.question10.TabIndex = 14;
            this.question10.TabStop = false;
            this.question10.Visible = false;
            // 
            // continueBTN10
            // 
            this.continueBTN10.BackColor = System.Drawing.SystemColors.MenuText;
            this.continueBTN10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.continueBTN10.Location = new System.Drawing.Point(263, 266);
            this.continueBTN10.Margin = new System.Windows.Forms.Padding(2);
            this.continueBTN10.Name = "continueBTN10";
            this.continueBTN10.Size = new System.Drawing.Size(69, 22);
            this.continueBTN10.TabIndex = 12;
            this.continueBTN10.Text = "Continue...";
            this.continueBTN10.UseVisualStyleBackColor = false;
            this.continueBTN10.Visible = false;
            this.continueBTN10.Click += new System.EventHandler(this.continueBTN10_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(271, 57);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(0, 13);
            this.label30.TabIndex = 8;
            // 
            // question10B
            // 
            this.question10B.BackColor = System.Drawing.SystemColors.MenuText;
            this.question10B.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question10B.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.question10B.Location = new System.Drawing.Point(357, 151);
            this.question10B.Name = "question10B";
            this.question10B.Size = new System.Drawing.Size(227, 103);
            this.question10B.TabIndex = 2;
            this.question10B.Text = "Self reflection\r\n";
            this.question10B.UseVisualStyleBackColor = false;
            this.question10B.Click += new System.EventHandler(this.question10B_Click);
            // 
            // question10A
            // 
            this.question10A.BackColor = System.Drawing.SystemColors.MenuText;
            this.question10A.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question10A.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.question10A.Location = new System.Drawing.Point(22, 151);
            this.question10A.Name = "question10A";
            this.question10A.Size = new System.Drawing.Size(227, 103);
            this.question10A.TabIndex = 1;
            this.question10A.Text = "Fighting\r\n";
            this.question10A.UseVisualStyleBackColor = false;
            this.question10A.Click += new System.EventHandler(this.question10A_Click);
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.SystemColors.Info;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(0, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(611, 43);
            this.label31.TabIndex = 0;
            this.label31.Text = "Do you enjoy a lot of fighting moments or moments of self reflection?";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // romance_score
            // 
            this.romance_score.AutoSize = true;
            this.romance_score.Location = new System.Drawing.Point(744, 269);
            this.romance_score.Name = "romance_score";
            this.romance_score.Size = new System.Drawing.Size(0, 13);
            this.romance_score.TabIndex = 16;
            this.romance_score.Visible = false;
            // 
            // horror_score
            // 
            this.horror_score.AutoSize = true;
            this.horror_score.Location = new System.Drawing.Point(744, 256);
            this.horror_score.Name = "horror_score";
            this.horror_score.Size = new System.Drawing.Size(0, 13);
            this.horror_score.TabIndex = 15;
            this.horror_score.Visible = false;
            // 
            // question9
            // 
            this.question9.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.question9.Controls.Add(this.continueBTN9);
            this.question9.Controls.Add(this.label27);
            this.question9.Controls.Add(this.question9B);
            this.question9.Controls.Add(this.question9A);
            this.question9.Controls.Add(this.label28);
            this.question9.Location = new System.Drawing.Point(125, 131);
            this.question9.Name = "question9";
            this.question9.Size = new System.Drawing.Size(613, 304);
            this.question9.TabIndex = 14;
            this.question9.TabStop = false;
            this.question9.Visible = false;
            // 
            // continueBTN9
            // 
            this.continueBTN9.BackColor = System.Drawing.SystemColors.MenuText;
            this.continueBTN9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.continueBTN9.Location = new System.Drawing.Point(263, 265);
            this.continueBTN9.Margin = new System.Windows.Forms.Padding(2);
            this.continueBTN9.Name = "continueBTN9";
            this.continueBTN9.Size = new System.Drawing.Size(69, 25);
            this.continueBTN9.TabIndex = 12;
            this.continueBTN9.Text = "Continue...";
            this.continueBTN9.UseVisualStyleBackColor = false;
            this.continueBTN9.Visible = false;
            this.continueBTN9.Click += new System.EventHandler(this.continueBTN9_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(271, 57);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(0, 13);
            this.label27.TabIndex = 8;
            // 
            // question9B
            // 
            this.question9B.BackColor = System.Drawing.SystemColors.MenuText;
            this.question9B.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question9B.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.question9B.Location = new System.Drawing.Point(357, 151);
            this.question9B.Name = "question9B";
            this.question9B.Size = new System.Drawing.Size(227, 103);
            this.question9B.TabIndex = 2;
            this.question9B.Text = "Intense danger\r\n";
            this.question9B.UseVisualStyleBackColor = false;
            this.question9B.Click += new System.EventHandler(this.question9B_Click);
            // 
            // question9A
            // 
            this.question9A.BackColor = System.Drawing.SystemColors.MenuText;
            this.question9A.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question9A.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.question9A.Location = new System.Drawing.Point(22, 151);
            this.question9A.Name = "question9A";
            this.question9A.Size = new System.Drawing.Size(227, 103);
            this.question9A.TabIndex = 1;
            this.question9A.Text = "Builds slowly";
            this.question9A.UseVisualStyleBackColor = false;
            this.question9A.Click += new System.EventHandler(this.question9A_Click);
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.Info;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(609, 57);
            this.label28.TabIndex = 0;
            this.label28.Text = "Would you rather watch a movie with a threat that builds slowly over time? or whe" +
    "re the danger is intense and immediate?\r\n";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // question8
            // 
            this.question8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.question8.Controls.Add(this.continueBTN8);
            this.question8.Controls.Add(this.label24);
            this.question8.Controls.Add(this.question8B);
            this.question8.Controls.Add(this.question8A);
            this.question8.Controls.Add(this.label25);
            this.question8.Location = new System.Drawing.Point(125, 131);
            this.question8.Name = "question8";
            this.question8.Size = new System.Drawing.Size(613, 304);
            this.question8.TabIndex = 14;
            this.question8.TabStop = false;
            this.question8.Visible = false;
            // 
            // continueBTN8
            // 
            this.continueBTN8.BackColor = System.Drawing.SystemColors.MenuText;
            this.continueBTN8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.continueBTN8.Location = new System.Drawing.Point(263, 268);
            this.continueBTN8.Margin = new System.Windows.Forms.Padding(2);
            this.continueBTN8.Name = "continueBTN8";
            this.continueBTN8.Size = new System.Drawing.Size(69, 22);
            this.continueBTN8.TabIndex = 12;
            this.continueBTN8.Text = "Continue...";
            this.continueBTN8.UseVisualStyleBackColor = false;
            this.continueBTN8.Visible = false;
            this.continueBTN8.Click += new System.EventHandler(this.continueBTN8_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(271, 57);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 13);
            this.label24.TabIndex = 8;
            // 
            // question8B
            // 
            this.question8B.BackColor = System.Drawing.SystemColors.MenuText;
            this.question8B.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question8B.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.question8B.Location = new System.Drawing.Point(357, 151);
            this.question8B.Name = "question8B";
            this.question8B.Size = new System.Drawing.Size(227, 103);
            this.question8B.TabIndex = 2;
            this.question8B.Text = "Thrills";
            this.question8B.UseVisualStyleBackColor = false;
            this.question8B.Click += new System.EventHandler(this.question8B_Click);
            // 
            // question8A
            // 
            this.question8A.BackColor = System.Drawing.SystemColors.MenuText;
            this.question8A.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.question8A.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.question8A.Location = new System.Drawing.Point(22, 151);
            this.question8A.Name = "question8A";
            this.question8A.Size = new System.Drawing.Size(227, 103);
            this.question8A.TabIndex = 1;
            this.question8A.Text = "Conflicts";
            this.question8A.UseVisualStyleBackColor = false;
            this.question8A.Click += new System.EventHandler(this.question8A_Click);
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.Info;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(0, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(611, 57);
            this.label25.TabIndex = 0;
            this.label25.Text = "Do you enjoy family conflicts or supernatural thrills?";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // question7
            // 
            this.question7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.question7.Controls.Add(this.ContinueBTN7);
            this.question7.Controls.Add(this.label21);
            this.question7.Controls.Add(this.Question7B);
            this.question7.Controls.Add(this.Question7A);
            this.question7.Controls.Add(this.label22);
            this.question7.Location = new System.Drawing.Point(125, 131);
            this.question7.Name = "question7";
            this.question7.Size = new System.Drawing.Size(613, 304);
            this.question7.TabIndex = 14;
            this.question7.TabStop = false;
            this.question7.Visible = false;
            // 
            // ContinueBTN7
            // 
            this.ContinueBTN7.BackColor = System.Drawing.SystemColors.MenuText;
            this.ContinueBTN7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ContinueBTN7.Location = new System.Drawing.Point(255, 258);
            this.ContinueBTN7.Margin = new System.Windows.Forms.Padding(2);
            this.ContinueBTN7.Name = "ContinueBTN7";
            this.ContinueBTN7.Size = new System.Drawing.Size(69, 22);
            this.ContinueBTN7.TabIndex = 12;
            this.ContinueBTN7.Text = "Continue...";
            this.ContinueBTN7.UseVisualStyleBackColor = false;
            this.ContinueBTN7.Visible = false;
            this.ContinueBTN7.Click += new System.EventHandler(this.ContinueBTN7_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(271, 57);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(0, 13);
            this.label21.TabIndex = 8;
            // 
            // Question7B
            // 
            this.Question7B.BackColor = System.Drawing.SystemColors.MenuText;
            this.Question7B.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Question7B.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Question7B.Location = new System.Drawing.Point(313, 141);
            this.Question7B.Name = "Question7B";
            this.Question7B.Size = new System.Drawing.Size(227, 103);
            this.Question7B.TabIndex = 2;
            this.Question7B.Text = "outsmarts the villian\r\n";
            this.Question7B.UseVisualStyleBackColor = false;
            this.Question7B.Click += new System.EventHandler(this.Question7B_Click);
            // 
            // Question7A
            // 
            this.Question7A.BackColor = System.Drawing.SystemColors.MenuText;
            this.Question7A.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Question7A.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Question7A.Location = new System.Drawing.Point(55, 141);
            this.Question7A.Name = "Question7A";
            this.Question7A.Size = new System.Drawing.Size(227, 103);
            this.Question7A.TabIndex = 1;
            this.Question7A.Text = "Life struggles";
            this.Question7A.UseVisualStyleBackColor = false;
            this.Question7A.Click += new System.EventHandler(this.Question7A_Click);
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.SystemColors.Info;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(0, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(611, 42);
            this.label22.TabIndex = 0;
            this.label22.Text = "Do you enjoy seeing movies with real life struggles or seeing someone outsmart th" +
    "e villian?\r\n ";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.label9.Location = new System.Drawing.Point(252, 93);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(368, 24);
            this.label9.TabIndex = 10;
            this.label9.Text = "Welcome to the Movie Recommender!";
            // 
            // exitBTN
            // 
            this.exitBTN.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBTN.Location = new System.Drawing.Point(628, 86);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(103, 39);
            this.exitBTN.TabIndex = 9;
            this.exitBTN.Text = "Exit Quiz";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // Results
            // 
            this.Results.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Results.Controls.Add(this.label7);
            this.Results.Controls.Add(this.label5);
            this.Results.Controls.Add(this.movie1);
            this.Results.Controls.Add(this.label4);
            this.Results.Controls.Add(this.movie3);
            this.Results.Controls.Add(this.movie2);
            this.Results.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Results.Location = new System.Drawing.Point(125, 131);
            this.Results.Name = "Results";
            this.Results.Size = new System.Drawing.Size(613, 346);
            this.Results.TabIndex = 15;
            this.Results.TabStop = false;
            this.Results.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(271, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 8;
            // 
            // movie3
            // 
            this.movie3.BackColor = System.Drawing.SystemColors.MenuText;
            this.movie3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movie3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.movie3.Location = new System.Drawing.Point(359, 175);
            this.movie3.Name = "movie3";
            this.movie3.Size = new System.Drawing.Size(227, 103);
            this.movie3.TabIndex = 2;
            this.movie3.Text = "\r\n";
            this.movie3.UseVisualStyleBackColor = false;
            // 
            // movie2
            // 
            this.movie2.BackColor = System.Drawing.SystemColors.MenuText;
            this.movie2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movie2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.movie2.Location = new System.Drawing.Point(6, 175);
            this.movie2.Name = "movie2";
            this.movie2.Size = new System.Drawing.Size(227, 103);
            this.movie2.TabIndex = 1;
            this.movie2.Text = "\r\n";
            this.movie2.UseVisualStyleBackColor = false;
            // 
            // movie1
            // 
            this.movie1.BackColor = System.Drawing.SystemColors.MenuText;
            this.movie1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movie1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.movie1.Location = new System.Drawing.Point(184, 57);
            this.movie1.Name = "movie1";
            this.movie1.Size = new System.Drawing.Size(227, 103);
            this.movie1.TabIndex = 9;
            this.movie1.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.Info;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(613, 43);
            this.label5.TabIndex = 13;
            this.label5.Text = "Your top 3 movies are...\r\n";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.Info;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(0, 301);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(613, 43);
            this.label7.TabIndex = 14;
            this.label7.Text = "Hope you enjoy!\r\n\r\n";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // movies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(921, 553);
            this.Controls.Add(this.container);
            this.Name = "movies";
            this.Text = "Form1";
            this.question1.ResumeLayout(false);
            this.question1.PerformLayout();
            this.question2.ResumeLayout(false);
            this.question2.PerformLayout();
            this.container.ResumeLayout(false);
            this.container.PerformLayout();
            this.Question3.ResumeLayout(false);
            this.Question3.PerformLayout();
            this.question5.ResumeLayout(false);
            this.question5.PerformLayout();
            this.question4.ResumeLayout(false);
            this.question4.PerformLayout();
            this.question6.ResumeLayout(false);
            this.question6.PerformLayout();
            this.question10.ResumeLayout(false);
            this.question10.PerformLayout();
            this.question9.ResumeLayout(false);
            this.question9.PerformLayout();
            this.question8.ResumeLayout(false);
            this.question8.PerformLayout();
            this.question7.ResumeLayout(false);
            this.question7.PerformLayout();
            this.Results.ResumeLayout(false);
            this.Results.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox question1;
        private System.Windows.Forms.Button Option1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel container;
        private System.Windows.Forms.Button Option2;
        private System.Windows.Forms.Label pointTotal;
        private System.Windows.Forms.GroupBox question2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Q2answer2;
        private System.Windows.Forms.Button Q2answer;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button continueBTN;
        private System.Windows.Forms.Label PointTotal2;
        private System.Windows.Forms.Button continueBTN2;
        private System.Windows.Forms.GroupBox Question3;
        private System.Windows.Forms.Label pointTotal3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button scareBTN2;
        private System.Windows.Forms.Button scareBTN1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button ContinueBTN3;
        private System.Windows.Forms.GroupBox question4;
        private System.Windows.Forms.Button continueBTN4;
        private System.Windows.Forms.Label pointTotal4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button ActionAnswerN;
        private System.Windows.Forms.Button ActionAnswerY;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox question10;
        private System.Windows.Forms.Button continueBTN10;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button question10B;
        private System.Windows.Forms.Button question10A;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox question9;
        private System.Windows.Forms.Button continueBTN9;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button question9B;
        private System.Windows.Forms.Button question9A;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox question8;
        private System.Windows.Forms.Button continueBTN8;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button question8B;
        private System.Windows.Forms.Button question8A;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox question7;
        private System.Windows.Forms.Button ContinueBTN7;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button Question7B;
        private System.Windows.Forms.Button Question7A;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox question6;
        private System.Windows.Forms.Button continueBTN6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button Question6B;
        private System.Windows.Forms.Button Question6A;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox question5;
        private System.Windows.Forms.Button continueBTN5;
        private System.Windows.Forms.Label pointTotal5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button FemaleAnswerN;
        private System.Windows.Forms.Button MaleAnswerY;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label comedy_score;
        private System.Windows.Forms.Label drama_score;
        private System.Windows.Forms.Label thriller_score;
        private System.Windows.Forms.Label romance_score;
        private System.Windows.Forms.Label horror_score;
        private System.Windows.Forms.GroupBox Results;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button movie1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button movie3;
        private System.Windows.Forms.Button movie2;
    }
}

