﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DailyTempss
{
    public partial class Form1 : Form
    {
        int numberOfTemps = 0;
        double enteredInput;
        const double maxTemp = 130;
        const double maxLowTemp = -20;
        private double avgTemp = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Visible = true;
            if (double.TryParse(textBox1.Text, out enteredInput))
            {
                if (enteredInput < maxTemp && enteredInput > maxLowTemp)
                {
                    listBox1.Items.Add($"You have entered {enteredInput}");
                    avgTemp += enteredInput;
                    numberOfTemps++;

                    if (numberOfTemps < 7)
                    {
                        textBox1.Text = "";
                    }
                    if (numberOfTemps == 7)
                    {
                        button1.Enabled = false;
                        displayTemps();
                    }

                }
                else 
                {
                    MessageBox.Show("Error! Please enter a tempature between -20 and 130 fahrenheit");
                }
            }
        }
        private void displayTemps()
        {
            double answerTemp = avgTemp / 7;
            label2.Text = $"Your average tempature is {answerTemp}";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            MessageBox.Show("Tempatures have been cleared");
            textBox1.Text = "";
            button1.Enabled = true;
            label2.Text = "";
        }
    }
}
