﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeliveryChanges
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int[] zipCodes = { 28713, 28719, 28779, 28738, 28786, 28704, 28716, 28906, 28901, 28904 };
        double[] shippingPrices = { 9.59, 11.19, 5.78, 4.65, 9.89, 7.90, 8.75, 3.45, 1.90, 4.78 };
        private void button1_Click(object sender, EventArgs e)
        {
            int zipEntered;
            double shippingPrice = 0;
            bool zipValid = false;
            if (int.TryParse(textBox1.Text, out zipEntered)) {

                for (int i = 0; i < zipCodes.Length; i++) {
                    if (zipEntered == zipCodes[i]) { 
                        zipValid = true;
                        shippingPrice = shippingPrices[i];
                    }
                }
                if (zipValid) { 
                    label2.Text = $"The pricing to ship to {zipEntered} is equal to {shippingPrice}.";
                    textBox1.Text = "";
                }
                else
                {
                    label2.Text = "Sorry, we cannot ship to your current location.";
                }
            }
            else
            {
                MessageBox.Show("ERROR. please enter a valid zip code.");
                textBox1.Text = "";
            }
        }
    }
}