﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MulitplicationTable
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int value, multiplier;
            if (int.TryParse(textBox1.Text, out value)) {
                for (multiplier = 1; multiplier <= 10; multiplier++)
                {
                    listBox1.Items.Add(value + " x " + multiplier + " = " + (value * multiplier));
                }
            }
            else
            {
                label2.Text = "please enter a valid number";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            label2.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
