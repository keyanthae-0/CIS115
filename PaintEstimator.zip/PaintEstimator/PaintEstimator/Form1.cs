﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PaintEstimator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double width;
            double length;
            if (double.TryParse(textBox1.Text, out width) && double.TryParse(textBox2.Text, out length))
            {
                double costTotal;
                costTotal = roomCalculatedTotal(length, width);
                label4.Text = String.Format($"For a room with a length of {length} and a width of {width} your total estimated cost is ${costTotal} at $6.00 per square footage.");
            }
            else
            {
                MessageBox.Show("ERROR, Please enter a valid lenght and width");
                textBox1.Text = "";
                textBox2.Text = "";
            }
        }


        private static double roomCalculatedTotal(double length, double width)
        {
            const double charge = 6.00;
            double firstWall;
            double secondWall;
            double cost;
            firstWall = (((length * 9) * charge) * 2);
            secondWall = (((width * 9) * charge) * 2);
            cost = firstWall + secondWall;
            return cost;
        }
    }
}

